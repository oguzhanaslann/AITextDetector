"""
AI Text Detection trainer package
""" 